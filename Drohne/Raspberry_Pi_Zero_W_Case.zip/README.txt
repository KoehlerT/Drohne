                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2488316
Raspberry Pi Zero W Case by mynameishamish is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

--

Update! People were mentioning the USB port holes were a little tight, so I added some extra breathing room around them, they should work much better now.

--


I couldn't find a Pi Zero W case that I liked, so I made one!

Based loosely on the Adafruit case, this case features all the access holes needed to get at all the ports (including camera). The pi fits in snug but NOT tight, so it won't damage the pi when installing. Installed on four pins that should fit the mounting holes perfectly, and then held in there by four pins in the lid. It's not going anywhere! 

SD slot is wide enough that you can get the card out without opening the case. Lid is simply push fit, this worked nicely at .2mm and .1mm (has a .1mm gap, which I find perfect for push fit).

# Print Settings

Printer Brand: Printrbot
Printer: Play
Rafts: No
Supports: No
Resolution: .2mm
Infill: 25%